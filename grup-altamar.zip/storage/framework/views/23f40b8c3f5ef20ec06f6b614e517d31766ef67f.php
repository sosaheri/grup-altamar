               <?php 
                ini_set('max_execution_time', 0);
                ini_set('memory_limit', '2048M');
                	$fecha = date("Y-m-d");

					$nuevafecha = strtotime ( '-7 day' , strtotime ( $fecha ) ) ;
					$nuevafecha = date ( 'Y-m-j' , $nuevafecha );
                ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Comprobante de Transacción</title>
      <link rel="stylesheet" href="<?php echo asset('admin/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>">
  </head>
  <body>
<span class="pull-right">Desde <?php echo e($nuevafecha); ?> hasta <?php echo e(date('Y-m-d')); ?></span>
<div><img height="45px" src="<?php echo e(url('logo.png')); ?>" alt="Logo altamar"></div>

<span class="text-center"><h1>Encomiendas</h1></span>

    <table class="table">
     				<tr>
     			  <th>Nro.</th>
                  <th>Remitente</th>
                  <th>Teléfono del Remitente</th>
                  <th>Correlativo</th>
                  <th>Fecha de Recepción</th>
                  <th>Descripción</th>
                  <th>Peso</th>
                  <th>Receptor</th>
                  <th>Teléfono del Receptor</th>
                  <th>Fecha de Salida</th>


                </tr>

 
                <?php if(count($transacciones) > 0): ?>
						<?php $__currentLoopData = $transacciones->where('fechaRecepcion', '>',$nuevafecha ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomiendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                        	<tr>
                                <td><?php echo e($encomiendas->id); ?></td>
                                <td><?php echo e($encomiendas->NombreyApellidoRemitente); ?></td>
                                <td><?php echo e($encomiendas->TelefonodeRemitente); ?></td>
                                <td><?php echo e($encomiendas->NumerodeCorrelativo); ?></td>
                                <td><?php echo e($encomiendas->fechaRecepcion); ?></td>
                                <td><?php echo e($encomiendas->descripcion); ?></td>
                                <td><?php echo e($encomiendas->PesoEncomienda); ?></td>
                                <td><?php echo e($encomiendas->NombreyApellidoReceptor); ?></td>
                                <td><?php echo e($encomiendas->TelefonoReceptor); ?></td>
                                <td><?php echo e($encomiendas->FechaDeSalida); ?></td>                         
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                
    </table>



  </body>
</html>