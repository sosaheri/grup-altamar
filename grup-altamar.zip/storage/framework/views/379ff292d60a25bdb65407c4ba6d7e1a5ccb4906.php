<!-- pdf.blade.php -->
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Comprobante de Transacción</title>
      <link rel="stylesheet" href="<?php echo asset('admin/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>">
  </head>
  <body>
<div><img height="45px" src="<?php echo e(url('logo.png')); ?>" alt="Logo altamar"></div>

<span class="text-center"><h1>Reporte de transacción</h1></span>

Fecha: <?php echo e($transacciones->created_at); ?>


    <table class="table table-bordered">
     <tr>
					<td><h1>Datos de Remesa</h1></td>
					<td></td>
				</tr>
				<tr>
					<td><h3>Fecha de Deposito</h3></td>
					<td><h4><?php echo e($transacciones->RemFechaDeposito); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Hora Deposito</h3> </td>
					<td><h4><?php echo e($transacciones->RemHoraDeposito); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Banco</h3></td>
					<td><h4><?php echo e($transacciones->RemBanco); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Número de Referencia</h3></td>
					<td><h4><?php echo e($transacciones->RemNumRef); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Oficina</h3></td>
					<td><h4><?php echo e($transacciones->RemOficina); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Beneficiario</h3></td>
					<td><h4><?php echo e($transacciones->RemBene); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Monto</h3></td>
					<td><h4><?php echo e($transacciones->RemMonto); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Tasa</h3></td>
					<td><h4><?php echo e($transacciones->Remtasa); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Banco receptor</h3></td>
					<td><h4><?php echo e($transacciones->RemBancoRec); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Registrado por</h3></td>
					<td><h4><?php echo e($transacciones->operador); ?></h4></td>
				</tr>	
    </table>



  </body>
</html>