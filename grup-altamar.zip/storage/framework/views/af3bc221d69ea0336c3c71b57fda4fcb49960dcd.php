<?php $__env->startSection('content'); ?>

<h1>Reportes Remesas</h1>


 <div class="box">
            <div class="box-header">
              <h3 class="box-title">Remesas</h3>

              <h3 class="pull-right"><a href="<?php echo e(action('ReportesController@downloadPDF2')); ?>" target="_blank"

                >Imprimir Últimos 7 días</a></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
                      <th>Fecha de Deposito</th>
              <th>Hora de Deposito</th>
              <th>Banco</th>
              <th>Numero Ref</th>
              <th>Oficina</th>
              <th>Beneficiario</th>
              <th>Monto</th>
              <th>Tasa</th>
              <th>Banco Receptor</th>
                </tr>
                </thead>
                <tbody>
        <?php if(count($rem) > 0): ?>
                        <?php $__currentLoopData = $rem->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                <tr>
                      <td><?php echo e($remesa->RemFechaDeposito); ?></td>
              <td><?php echo e($remesa->RemHoraDeposito); ?></td>
              <td><?php echo e($remesa->RemBanco); ?></td>
              <td><?php echo e($remesa->RemNumRef); ?></td>
              <td><?php echo e($remesa->RemOficina); ?></td>
              <td><?php echo e($remesa->RemBene); ?></td>
              <td><?php echo e($remesa->RemMonto); ?></td>
              <td><?php echo e($remesa->Remtasa); ?></td>
              <td><?php echo e($remesa->RemBancoRec); ?></td>
                </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>                 

                
                <tfoot>
                <tr>
                      <th>Fecha de Deposito</th>
              <th>Hora de Deposito</th>
              <th>Banco</th>
              <th>Numero Ref</th>
              <th>Oficina</th>
              <th>Beneficiario</th>
              <th>Monto</th>
              <th>Tasa</th>
              <th>Banco Receptor</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>