<?php $__env->startSection('content'); ?>

<h1>Reportes Encomiendas</h1>


<div class="box">
            <div class="box-header">
              <h3 class="pull-left">Encomiendas</h3>
              <h3 class="pull-right"><a href="">Descargar Excel</a></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Remitente</th>
                  <th>Teléfono Remitente</th>
                  <th>Correlativo</th>
                  <th>Fecha Recepción</th>
                  <th>Descripción</th>
                  <th>Peso</th>
                  <th>Receptor</th>
                  <th>Teléfono de receptor</th>
                   <th>Fecha de Salida</th>

                </tr>
                </thead>
                <tbody>
				<?php if(count($enc) > 0): ?>
                        <?php $__currentLoopData = $enc->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomiendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                	
			                <tr>
			                 
			    	<td><?php echo e($encomiendas->NombreyApellidoRemitente); ?></td>
    				<td><?php echo e($encomiendas->TelefonodeRemitente); ?></td>
    				<td><?php echo e($encomiendas->NumerodeCorrelativo); ?></td>
    				<td><?php echo e($encomiendas->fechaRecepcion); ?></td>
    				<td><?php echo e($encomiendas->descripcion); ?></td>
    				<td><?php echo e($encomiendas->PesoEncomienda); ?></td>
    				<td><?php echo e($encomiendas->NombreyApellidoReceptor); ?></td>
    				<td><?php echo e($encomiendas->TelefonoReceptor); ?></td>
    				<td><?php echo e($encomiendas->FechaDeSalida); ?></td>
			                </tr>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    <?php endif; ?>    
                
                <tfoot>
                <tr>
                  <th>Remitente</th>
                  <th>Teléfono Remitente</th>
                  <th>Correlativo</th>
                  <th>Fecha Recepción</th>
                  <th>Descripción</th>
                  <th>Peso</th>
                  <th>Receptor</th>
                  <th>Teléfono de receptor</th>
                   <th>Fecha de Salida</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>