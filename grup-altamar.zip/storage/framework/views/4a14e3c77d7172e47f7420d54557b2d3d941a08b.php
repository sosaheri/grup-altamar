<?php $__env->startSection('content'); ?>

<!--top-->
	<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Transacción #<?php echo e($transacciones->id); ?> de fecha <?php echo e($transacciones->created_at); ?></h3>

        </div>
<!--fin top-->

​<!--cuerpo-->
	<div class="box-body">

		<table class="table table-hover">
			<thead>
				<tr>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><h1>Datos de Remesa</h1></td>
					<td></td>
				</tr>
				<tr>
					<td><h3>Fecha de Deposito</h3></td>
					<td><h4><?php echo e($transacciones->RemFechaDeposito); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Hora Deposito</h3> </td>
					<td><h4><?php echo e($transacciones->RemHoraDeposito); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Banco</h3></td>
					<td><h4><?php echo e($transacciones->RemBanco); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Número de Referencia</h3></td>
					<td><h4><?php echo e($transacciones->RemNumRef); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Oficina</h3></td>
					<td><h4><?php echo e($transacciones->RemOficina); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Beneficiario</h3></td>
					<td><h4><?php echo e($transacciones->RemBene); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Monto</h3></td>
					<td><h4><?php echo e($transacciones->RemMonto); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Tasa</h3></td>
					<td><h4><?php echo e($transacciones->Remtasa); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Banco receptor</h3></td>
					<td><h4><?php echo e($transacciones->RemBancoRec); ?></h4></td>
				</tr>
				<tr>
					<td><h3>Registrado por</h3></td>
					<td><h4><?php echo e($transacciones->operador); ?></h4></td>
				</tr>																		
			</tbody>
		</table>
	</div>
<!--fin cuerpo-->


  	  <div>	
        <!-- /.box-footer -->

              <div class="box-footer">

                <a href='<?php echo e(url("transaccionesRemesas")); ?>'><button type="button" class="btn btn-default btn-lg">Regresar</button></a>
				<a href="<?php echo e(action('RemesasController@downloadPDF', $transacciones->id)); ?>" target="_blank"><button type="button" class="btn btn-default btn-lg">Generar PDF</button></a>



                
              </div>
        <!-- fin /.box-footer-->
      </div>              

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>