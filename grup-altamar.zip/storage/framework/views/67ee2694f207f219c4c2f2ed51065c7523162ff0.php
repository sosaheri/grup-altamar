<?php $__env->startSection('content'); ?>

<h1>Listado de Usuarios</h1>

<div class="col-md-10 col-md-offset-1">
    <div class="box">
         <div class="box-header">
                  <h3 class="box-title">Listado de Usuarios</h3>

                  <div class="box-tools">
                         <div style="margin: -20px 0px !important;"><?php echo e($users->render()); ?></div>

                  </div>
         </div>

         <div class="box-body table-responsive no-padding">


              <?php if(session('info')): ?>

                    <div class="alert alert-danger alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> <?php echo e(session('info')); ?></h4>
                      
                    </div>

              <?php endif; ?>


              <table class="table table-hover">
                <tr>
                  <th>Nombre de Usuario</th>
                  <th>Correo</th>
                  <th>Rol</th>
                  <th></th>

                </tr>

 
                 <?php if(count($users) > 0): ?>
                        <?php $__currentLoopData = $users->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                          <td><?php echo e($user->name); ?></td>
                          <td><?php echo e($user->email); ?></td>
                          
                          <td><?php echo e($user->rol); ?></td>
                          <td><a href="<?php echo e(url("/deleteUsr/{$user->id}")); ?>"><span class="label label-danger">Eliminar</span></a></td>
                          
                 </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

              </table>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>