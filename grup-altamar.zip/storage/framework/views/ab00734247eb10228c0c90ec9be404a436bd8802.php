<?php $__env->startSection('content'); ?>

<h1>Transacciones de Remesas en el Sistema</h1>

<div class="col-md-10 col-md-offset-1">
	<div class="box">
		 <div class="box-header">
	              <h3 class="box-title">Remesas</h3>

	              <div class="box-tools">
                   <div style="margin: -20px 0px !important;"><?php echo e($transacciones->render()); ?></div>

              </div>
	     </div>

	     <div class="box-body table-responsive no-padding">
              <table class="table table-hover">

              <?php if(session('info')): ?>

                    <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> <?php echo e(session('info')); ?></h4>
                      
                    </div>

              <?php endif; ?>

                <tr>
                  <th>Fecha de Deposito</th>
                  <th>Hora</th>
                  <th>Banco</th>
                  <th>Referencia del Deposito</th>
                  <th>Operador</th>
                  <th>PDF</th>
                  <th>Acciones</th>


                </tr>
                <?php if(count($transacciones) > 0): ?>
                  <?php $__currentLoopData = $transacciones->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remesas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                         <tr>
                          <td><?php echo e($remesas->RemFechaDeposito); ?></td>
                          <td><?php echo e($remesas->RemHoraDeposito); ?></td>
                          <td><?php echo e($remesas->RemBanco); ?></td>
                          <td><?php echo e($remesas->RemNumRef); ?></td>
                          <td><?php echo e($remesas->operador); ?></td>
                          <td></td>
                          <td><a href="<?php echo e(url("/readRem/{$remesas->id}")); ?>"><span class="label label-info">Ver</span></a> |
                          <?php if((Auth::user()->name == $remesas->operador) OR (Auth::user()->rol == 'administrador')): ?>

                               <a href='<?php echo e(url("/updateRem/{$remesas->id}")); ?>'><span class="label label-warning">Editar</span></a> |
                                <a href="<?php echo e(url("/deleteRem/{$remesas->id}")); ?>"><span class="label label-danger">Borrar</span></a></td>
                          <?php endif; ?>
                        </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
              </table>
            </div>
 	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>