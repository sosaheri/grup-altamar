               <?php 
                ini_set('max_execution_time', 0);
                ini_set('memory_limit', '2048M');
                	$fecha = date("Y-m-d");

					$nuevafecha = strtotime ( '-7 day' , strtotime ( $fecha ) ) ;
					$nuevafecha = date ( 'Y-m-j' , $nuevafecha );
                ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Reporte</title>
      <link rel="stylesheet" href="<?php echo asset('admin/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>">
  </head>
  <body>
<span class="pull-right">Desde <?php echo e($nuevafecha); ?> hasta <?php echo e(date('Y-m-d')); ?></span>
<div><img height="45px" src="<?php echo e(url('logo.png')); ?>" alt="Logo altamar"></div>

<span class="text-center"><h1>Remesas</h1></span>

    <table class="table">
     				<tr>
     			        <th>Nro.</th>
                  <th>Fecha de Deposito</th>
                  <th>Hora de Deposito</th>
                  <th>Banco</th>
                  <th>Número de Referencia</th>
                  <th>Oficina</th>
                  <th>Beneficiario</th>
                  <th>Monto</th>
                  <th>Tasa</th>
                  <th>Banco Receptor</th>


                </tr>

 
                <?php if(count($transacciones) > 0): ?>
						<?php $__currentLoopData = $transacciones->where('RemFechaDeposito', '>',$nuevafecha ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                        	<tr>
                                <td><?php echo e($remesa->id); ?></td>
                                <td><?php echo e($remesa->RemFechaDeposito); ?></td>
                                <td><?php echo e($remesa->RemHoraDeposito); ?></td>
                                <td><?php echo e($remesa->RemBanco); ?></td>
                                <td><?php echo e($remesa->RemNumRef); ?></td>
                                <td><?php echo e($remesa->RemOficina); ?></td>
                                <td><?php echo e($remesa->RemBene); ?></td>
                                <td><?php echo e($remesa->RemMonto); ?></td>
                                <td><?php echo e($remesa->RemTasa); ?></td>
                                <td><?php echo e($remesa->RemBancoRec); ?></td>                         
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                
    </table>



  </body>
</html>