<?php $__env->startSection('content'); ?>

<h1>Transacciones de Encomiendas en el Sistema</h1>

<div class="col-md-10 col-md-offset-1">
	<div class="box">
		 <div class="box-header">
	              <h3 class="box-title">Encomiendas</h3>

	              <div class="box-tools">
                    <div style="margin: -20px 0px !important;"><?php echo e($transacciones->render()); ?></div>
              </div>
	     </div>

	     <div class="box-body table-responsive no-padding">
              <table class="table table-hover">

              <?php if(session('info')): ?>

                    <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> <?php echo e(session('info')); ?></h4>
                      
                    </div>

              <?php endif; ?>
                

                <tr>
                  <th>Fecha de Recepción</th>
                  <th>Nombre Receptor</th>
                  <th>Operador</th>
                  <th>PDF</th>

                </tr>
                
                <?php if(count($transacciones) > 0): ?>
                        <?php $__currentLoopData = $transacciones->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encomiendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($encomiendas->fechaRecepcion); ?></td>
                                <td><?php echo e($encomiendas->NombreyApellidoReceptor); ?></td>
                                <td><?php echo e($encomiendas->operador); ?></td>
                                <td></td>
                                <td><a href='<?php echo e(url("/readEnc/{$encomiendas->id}")); ?>'><span class="label label-info">Ver</span></a> |
                                <?php if((Auth::user()->name == $encomiendas->operador) OR (Auth::user()->rol == 'administrador')): ?>
  
                                      <a href='<?php echo e(url("/updateEnc/{$encomiendas->id}")); ?>'><span class="label label-warning">Editar</span></a> |
                                    <a href="<?php echo e(url("/deleteEnc/{$encomiendas->id}")); ?>"><span class="label label-danger">Borrar</span></a> |
                                <?php endif; ?>
                              </td>
                                
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                
              </table>
            </div>
 	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>