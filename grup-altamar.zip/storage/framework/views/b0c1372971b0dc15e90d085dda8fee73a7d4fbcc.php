<?php $__env->startSection('content'); ?>


​	<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Transacción #<?php echo e($transacciones->id); ?> de fecha <?php echo e($transacciones->created_at); ?></h3>

        </div>
        <div class="box-body">

<table class="table table-hover">
	<thead>
		<tr>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><h1>Datos de Remitente</h1></td>
			<td></td>
		</tr>
		<tr>
			<td><h3>Nombre y Apellido</h3></td>
			<td><h4><?php echo e($transacciones->NombreyApellidoRemitente); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Documento de Identidad</h3> </td>
			<td><h4><?php echo e($transacciones->DocumentodeIdentidadRemitente); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Teléfono del Remitente</h3></td>
			<td><h4><?php echo e($transacciones->TelefonodeRemitente); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Número de Correlativo</h3></td>
			<td><h4><?php echo e($transacciones->NumerodeCorrelativo); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Fecha de Recepción</h3></td>
			<td><h4><?php echo e($transacciones->fechaRecepcion); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Descripción</h3></td>
			<td><h4><?php echo e($transacciones->descripcion); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Peso de La encomienda</h3></td>
			<td><h4><?php echo e($transacciones->PesoEncomienda); ?></h4></td>
		</tr>
		<tr>
			<td><h1>Datos del Receptor</h1></td>
			<td><h4></h4></td>
		</tr>

		<tr>
			<td><h3>Nombre y Apellido del Receptor</h3></td>
			<td><h4><?php echo e($transacciones->NombreyApellidoReceptor); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Documento de Identidad del Receptor</h3></td>
			<td><h4><?php echo e($transacciones->DocumentodeIdentidadReceptor); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Teléfono del Receptor</h3></td>
			<td><h4><?php echo e($transacciones->TelefonoReceptor); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Dirección de Retiro de la Encomienda</h3></td>
			<td><h4><?php echo e($transacciones->DireccionRetiro); ?></h4></td>
		</tr>
		<tr>
			<td><h3>Fecha de Salida de la Encomienda</h3></td>
			<td><h4><?php echo e($transacciones->FechaDeSalida); ?></h4></td>
		</tr>
				<tr>
			<td><h3>Registrado por</h3></td>
			<td><h4><?php echo e($transacciones->operador); ?></h4></td>
		</tr>																		
	</tbody>
</table>
			
        	
        </div>
        <!-- /.box-body -->
              <div class="box-footer">

                <a href='<?php echo e(url("transaccionesEncomiendas")); ?>'><button type="button" class="btn btn-default btn-lg">Regresar</button></a>
				<a href="<?php echo e(action('EncomiendasController@downloadPDF', $transacciones->id)); ?>" target="_blank"><button type="button" class="btn btn-default btn-lg">Generar PDF</button></a>



                
              </div>
        <!-- /.box-footer-->
      </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>