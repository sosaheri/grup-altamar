<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Remesa extends Model
{
    //
}
